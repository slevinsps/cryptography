cat /proc/fortune
cat /proc/fortune
cat /proc/fortune