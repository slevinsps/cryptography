echo "People are naturally attracted to you." > /proc/fortune
echo "You learn from your mistakes... You will learn a lot today." > /proc/fortune
echo "A dream you have will come true." > /proc/fortune